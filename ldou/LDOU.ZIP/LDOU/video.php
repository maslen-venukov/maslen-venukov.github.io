<?php // Атрибуты IFRAME должны быть следующими width="100%" height="400" для корректной работы ?>

<?php // Видео о курсе ?>

<?php if ( $_GET["video"] == "about" ): ?>

	<iframe width="100%" height="400" src="https://www.youtube.com/embed/6w-WkduH74Y" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php endif; ?>


<?php //видео отзывов, заполняется по очереди ?>

<?php if ( $_GET["video"] == "review" && $_GET["index"] == "1" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/LYCjSnzQ-ZE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php elseif ( $_GET["video"] == "review" && $_GET["index"] == "2" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/BHRp5sBarS8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php elseif ( $_GET["video"] == "review" && $_GET["index"] == "3" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/dhZcxmwU1Kk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php elseif ( $_GET["video"] == "review" && $_GET["index"] == "4" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/tMWRrAHZLrE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php elseif ( $_GET["video"] == "review" && $_GET["index"] == "5" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/oHumXbkY4wQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php elseif ( $_GET["video"] == "review" && $_GET["index"] == "6" ): ?>

<iframe width="100%" height="400" src="https://www.youtube.com/embed/tfAof8qwjnY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php endif; ?>