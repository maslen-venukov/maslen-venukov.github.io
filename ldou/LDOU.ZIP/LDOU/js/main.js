//mobile menu
const trigger = $('.tm-trigger');
const menuPanel = $('.tm-panel');

//modal
const darkness = $(".darkness");
const hider = $(".modal-x");
const modal = $(".modal");
const video = $('#video');

darkness.on("click", function(){
	darkness.hide();
	modal.hide();
});

hider.on("click", function(){
	darkness.hide();
	modal.hide();
});

trigger.on("click", function(){
	trigger.toggleClass("active");
	menuPanel.toggleClass("active");
});


document.onkeydown = function(evt) {
    evt = evt || window.event;
    if (evt.keyCode == 27) {
		darkness.hide();
		modal.hide();        
    }
};

// активные пункты меню
menuPanel.find("a").each(function(){
	var $this = $(this);
	if ( $this.attr("href") == ("/" + location.hash) ) {
		$this.addClass("active");
	}
	$this.on("click", function(){
		if (menuPanel.is(".active")) {
			trigger.toggleClass("active");
			menuPanel.toggleClass("active");
		}
		$(this).addClass("active").closest("li").siblings().find("a").removeClass("active");
	});
});


//reviews
let bigvideos = $(".main-reviews--bigvid");
$(".main-reviews--smallvid").find("span").on("click", function(){
	bigvideos.removeClass("active").eq( $(this).data("index") ).addClass("active");
});




//Временный код для окна спасибо. его нужно убрать когда будет подключена форма.
$("form").on("submit", function(e){
	e.preventDefault();
	$('#thanks').show();
	darkness.show();
});


// Получение видео о ЛДОУ
$(".main-v--video").on("click", function(e){
	e.preventDefault();
	$.ajax({
		url: '/video.php',
		type: 'GET',
		data: {video: 'about'},
	})
	.done(function(data) {
		video.show().find(".modal-in").html(data);
		darkness.show();
	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
	
});

//Получение видео отзыва
$(".main-reviews--bigvid").on("click", function(e){
	e.preventDefault();
	var $this = $(this);
	$.ajax({
		url: $this.attr("href"),
		type: 'GET',
	})
	.done(function(data) {
		video.show().find(".modal-in").html(data);
		darkness.show();
	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
	
});

